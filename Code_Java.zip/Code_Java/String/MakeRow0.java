public class MakeRow0 {
    public static void updateRow(int mat[][], int row, int m){
        for(int col=0;col<m;col++){
            if(mat[row][col]!=0){
                mat[row][col]=-1;
            }
        }
        
    }
    public static void updateCol(int mat[][], int col, int n){
        for(int row=0;row<n; row++){
            if(mat[row][col]!=0){
                mat[row][col]=-1;
            }
        }
        
    }
    public static void printmatrix(int mat[][]){
        int n = mat.length;
        int m = mat[0].length;
        for(int i=0;i<n; i++){
            for(int j=0;j<m;j++){
                System.out.print(mat[i][j]+" ");
            }
            System.out.println();
        }
    }
    public static void main(String args[]){
        int[][] mat = {
            {1, 2, 3},
            {4, 0, 6},
            {7, 8, 0}
        };
        int n= mat.length;       // row
        int m= mat[0].length;   // column
        System.out.println("Actual Matrix:- ");
        printmatrix(mat);
        for(int row= 0; row<n; row++){
            for(int col=0; col<m; col++){
                if(mat[row][col]==0){
                    updateRow(mat,row, m);
                    updateCol(mat,col, n);
                }
            }
        }
        System.out.println("After Update Matrix:- ");
        printmatrix(mat);

        for(int row= 0; row<n; row++){
            for(int col=0; col<m; col++){
                if(mat[row][col]==-1){
                    mat[row][col]=0;
                }
            }
        }
        System.out.println("After Conversion Matrix:- ");
        printmatrix(mat);
    }
    
}
