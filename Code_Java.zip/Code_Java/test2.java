import java.util.*;
public class test2 {
public static void main(String[] args) {
    Scanner sc= new Scanner(System.in);
    System.out.println("Please Enter your name");
    String name= sc.next();
    System.out.println(name);
    test2 obj= new test2();
    
    System.out.println(obj.add());
}
    public static int add(){
        System.out.print("Enter the 1st number");
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = a+b;
        return c;
    }
}
