class javatest1{
    public static int add(int a, int b){
        int c=a+b;
        return c;
    }
    public static void main(String[] args) {
        System.out.println("Hello");
        
        int a=5;
        int b=6;
        int c= add(a,b);
        System.out.println(c);
    }
   
}