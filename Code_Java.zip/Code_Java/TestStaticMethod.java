// Class with static methods
class Calculator {

    // Static method to add two numbers
    public static int add(int a, int b) {
        return a + b;
    }

    // Static method to multiply two numbers
    public  int multiply(int a, int b) {
        return a * b;
    }
}

// Another class that uses the static methods from Calculator
public class TestStaticMethod {

    public static void main(String[] args) {
        // Calling the static methods from the Calculator class without creating an object

        // Using class name to call static method
        int sum = Calculator.add(10, 20); 
        System.out.println("Sum: " + sum); // Output: Sum: 30
        Calculator obj= new Calculator();
        // Calling another static method from Calculator
        int product = obj.multiply(10, 20);
        System.out.println("Product: " + product); // Output: Product: 200
    }
}
