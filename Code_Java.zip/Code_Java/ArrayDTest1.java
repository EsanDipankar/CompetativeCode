import java.util.*;
public class ArrayDTest1 {
    public static void main(String[] args){
        int N=3;
        int M=3;
        int[][] arr= new int[N][M];
        Scanner scn= new Scanner(System.in);
        System.out.println("Please Enter the Number");
        for(int i=0;i<N;i++){
            for(int j=0;j<M;j++){
                arr[i][j]= scn.nextInt();
            }
        }
        int ans[][]= new int[1][N];
        for(int i=0;i<N;i++){
            int colSum=0;
            for(int j=0;j<M;j++){
                colSum+=arr[j][i];
                // System.out.print(arr[j][i]+", ");
            }
            ans[0][i]=colSum;
            System.out.println(colSum);
        }

    }
    

}
