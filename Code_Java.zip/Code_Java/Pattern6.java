import java.util.*;

public class Pattern6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Ask the user for the number of rows
        System.out.print("Enter the number of rows for the pyramid: ");
        int rows = scanner.nextInt();

        // Loop to print the pyramid
        for (int i = 1; i <= rows; i++) {
            // Print spaces for each row
            for (int j = rows - i; j > 0; j--) {
                System.out.print("  ");  // Double spaces for better alignment
            }
            // Print stars with spaces between them
            for (int k = 1; k <= i; k++) {
                System.out.print("*   "); // Star followed by three spaces
            }
            // Move to the next line after each row
            System.out.println();
        }

        scanner.close();
        System.out.println("Please enetr the no");
        int b= scanner.nextInt();

        System.out.println(b);
    }
}
