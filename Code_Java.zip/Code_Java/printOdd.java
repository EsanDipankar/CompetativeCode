import java.util.Scanner;
public class printOdd {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        // Input n and print squares of integers less than n
        int n = scn.nextInt();
        int i = 0;
        while (i * i < n) {
            System.out.println(i * i);
            i += 1;
        }
        // Create an instance of odd class to print odd numbers
        odd obj = new odd();
        obj.printOddNumbers(n);  // Call method to print odd numbers
    }
}
class odd {
    // Method to print odd numbers
    public void printOddNumbers(int n) {
        int i = 0;
        while (i < n) {
            if (i % 2 != 0) {  // Check for odd numbers
                System.out.println(i);
            }
            i++;
        }
    }
}
