import java.util.*;
class FunctionalityTest{
    public static void main(String args[]){
        HashMap<Integer,Integer> HM= new HashMap<Integer,Integer>();
        // print is HashMap is Empty or Not
        // System.out.println(HM.isEmpty());
        HM.put(1,2);
        // System.out.println(HM.get(1)); // When Key is Present return value 
        // System.out.println(HM.get(2)); // When Key is not Present return null
        HM.put(2,10);
        // System.out.println(HM.get(2)); // When Key is not Present return null
        int n=HM.put(2,20);
        // System.out.println(n); // When Key is not Present return null
        System.out.println(HM.size());
        System.out.println(HM.values());
        int arr[] =  HM.values();

    }
}