import java.util.*;
public class Pattern3 {
    public static void main(String args[]){
        Scanner scn = new Scanner(System.in);
        int n=scn.nextInt();
		for(int row=0;row<n;row++){
			for(int col=1;col<=n;col++){
				if(col<=n-row){
					System.out.print(col+" ");
				}
				else{
					System.out.print(" ");
				}
			}
			System.out.println();
		}
    }
}
