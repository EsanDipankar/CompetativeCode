import java.util.Scanner;

public class Electricbill {
    public static void main(String srgs[]){
        Scanner sc= new Scanner(System.in);
        int unit = sc.nextInt();
        double amount=0;
        if(unit<=50){
            amount=unit*0.5;
        }
        else if(unit>50 && unit<=150){
            amount= (50*0.5+(unit-50)*0.75);
        }
        else if(unit>=150 && unit<=200){
            amount= (50*0.5+100*0.75 +(unit-150)*1.20);
        }
        else{
            amount= ((50*0.5+100*0.75 + 100*1.20)+(unit-250)*1.50);
        }
        int total_cost= (int) Math.floor(amount+(amount*20)/100);
        System.out.println("Total Electic bill is:- "+ total_cost);
    }
}
