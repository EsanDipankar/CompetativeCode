import java.util.HashMap;
public class Hashmap1 {
    public static void main(String args[]){
     HashMap<Integer, String> hmap1= new HashMap<Integer, String>();
     hmap1.put(1,"Sanket");
     hmap1.put(2,"Dipankar");
     hmap1.put(3,"Avinsh");
     System.out.println(hmap1);
     hmap1.put(3,"Avinsh");
     
     System.out.println(hmap1.remove(3));
     hmap1.put(3,"Avinsh");
     System.out.println(hmap1.size());
     for(String num: hmap1.values()){
        System.out.println(num);
     }
    
    }
}
