
import java.util.*;

public class Testarray1 {
    public static void main(String args[]){
        int[] fstarr= new int[5];
        Scanner s = new Scanner(System.in);
        for(int i=0;i<fstarr.length;i++){
            System.out.println("Please Enter the Next Number");
            fstarr[i]= s.nextInt();
        }
        
        for(int j=0;j<fstarr.length;j++){
            System.out.println(fstarr[j]);
        }
        System.out.println("I am printing the all element of list");
        ArrayList<Integer> arr1 = new ArrayList<>();
        for(int i=0;i<10;i++){
            arr1.add(i);            
        }
        for(int i=0; i<= arr1.size(); i++){
            System.out.println(arr1.get(i));
        }

    }
}
