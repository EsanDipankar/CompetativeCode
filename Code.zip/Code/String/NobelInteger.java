import java.util.*;

public class NobelInteger {
    public static void main(String args[]){
        Scanner sc= new Scanner(System.in);
        int arr[]= new int[5];
        for(int i=0;i<5; i++){
            arr[i]= sc.nextInt();
        }
        int n= sc.nextInt();
        Nobeint(arr,5);
    }
    //{1,1,3,3,}
    public static void Nobeint(int arr[], int n){
        float status= 0;
        int count=0;
        int flagarr[]= new int[5];
        if(arr[0]==0){
            flagarr[0]=1;
        }
        else{
            flagarr[0]=0;
        }
        for(int i=1;i<n;i++){
            if(arr[i-1]== arr[i]){
                if(flagarr[i-1] ==0){
                    flagarr[i]=0;
                }
                else{
                    flagarr[i]=1;
                }
            }
            else{
                if(arr[i]==i){
                    flagarr[i]=1;
                }
                else{
                    flagarr[i]=0;
                }
            }
        }
        for(int i=0;i<n; i++){
            if(flagarr[i]==1){
                count++;
            }
        }
        System.out.println("Total No of Nobel Integer:- "+count);

    }
    public static void SelectionSort(int arr[], int n){
        // array name is arr;
        // size= n;
        for(int i =0;i<n;i++){
            int mini= Integer.MAX_VALUE;
            for(int j=i; j<n;j++){
                
            }
        }   
    }
}
