public class PrintAntiDiagonal {
    public static void main(String[] args){
        int[][] arr= new int[3][3];
        int arr1D[]= {1,2,3,4,5,6,7,8,9};
        int counter=0;
        int n=3;
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){ 
                arr[i][j]=arr1D[counter];
                counter++;
            }
        }
        // int row=0;
        for(int col=0;col<n;col++){
            int startingRow=0;
            int startingColumn=col;
            while(startingColumn>=0 && startingRow<3){
                System.out.print(arr[startingRow][startingColumn]+" ");
                startingRow++;
                startingColumn--;
            }
            System.out.println();
        }
       
        int col=n-1;
        for(int row=1; row<n; row++){
            int startingCol=col;
            int staringRow= row;
            while(staringRow<n && startingCol<=col){ // while(staringRow<n && startingCol>0)
                System.out.print(arr[staringRow][startingCol]+" ");
                staringRow++;
                startingCol--;
            }
            System.out.println();
        }
        // for(int i=0;i<3;i++){
        //     for(int j=0;j<3;j++){ 
        //         System.out.print(arr[i][j]+" ");    
        //     }
        //     System.out.println();
        // }
    }
}
