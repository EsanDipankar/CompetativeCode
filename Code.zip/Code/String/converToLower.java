import java.util.*;
public class converToLower{
    public static void main(String args[]){
        String s="azd"; 
        String ans= SndCode(s);
        System.out.println(ans);
        System.out.println(ThirdCode("Scaler"));
        ForthCode("scaler");
    }
    public static String SndCode(String S){
        String ans="";
        for(int i=0; i<S.length(); i++){
            int a=S.charAt(i);
            a=a%96;
            ans=ans+ S.charAt(i)+a;
        }

        return ans;
    }
    public static String ThirdCode(String S){
        String ans="";
        for(int i=0;i<S.length() -1;i++){
            ans= ans+S.charAt(i);
        }
        return ans;
    }
    public static void ForthCode(String S){
        int vowel=0;
        for(int i=0; i<S.length(); i++){
            if(S.charAt(i)=='a' || S.charAt(i)=='e' || S.charAt(i)=='i' || S.charAt(i)=='o' || S.charAt(i)=='u'){
                vowel++;
            }
        }
        int consonent = S.length()- vowel;
        System.out.print(vowel +" " + consonent);
    }
}