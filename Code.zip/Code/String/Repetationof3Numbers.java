public class Repetationof3Numbers{
    public static void main(String args[]){
        int[] A={3,2,1,2,1,3,1};
        int count= repeatedNumber(A);
        System.out.print(count);

    }
    public static int repeatedNumber(int[] A) {
        int candidate1 = A[0], candidate2 = A[0];
        int count1 = 0, count2 = 0;
     
        // Phase 1: Find candidates
        for(int num : A) {
            if(count1 == 0 && num != candidate2) {
                candidate1 = num;
                count1 = 1;
            }
            else if(count2 == 0 && num != candidate1) {
                candidate2 = num;
                count2 = 1;
            }
            else if(num == candidate1) count1++;
            else if(num == candidate2) count2++;
            else {
                count1--;
                count2--;
            }
        }
     
        // Phase 2: Verify counts
        count1 = 0;
        count2 = 0;
        for(int num : A) {
            if(num == candidate1) count1++;
            else if(num == candidate2) count2++;
        }
     
        if(count1 > A.length/3) return candidate1;
        if(count2 > A.length/3) return candidate2;
        return -1;
    }
}