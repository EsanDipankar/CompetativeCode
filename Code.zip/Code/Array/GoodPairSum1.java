import java.util.ArrayList;

class GoodPairSum{
    public static void main(String args[]){
        ArrayList<Integer> arr= new ArrayList<>();
        arr.add(4);
        arr.add(3);
        arr.add(7);
        arr.add(6);
        arr.add(8);
        int Sumofminmax= MinMax(arr);
        ReverseArrayKNode(arr,3);
    }
    public static int MinMax(ArrayList<Integer> A){
        int N=A.size();
        int mini=A.get(0);
        int maxi=A.get(0);
        for(int i=0;i<N;i++){
            if(A.get(i)>maxi){
                maxi=A.get(i);
            }
            if(A.get(i)<mini){
                mini=A.get(i);
            }
        }
        return mini+maxi;
    }
    public static void ReverseArrayKNode(ArrayList<Integer> A, int k){
        System.out.println(A);
        int N= A.size();
        for(int i=0; i<N;i=i+k){
            int j = Math.min(i + k - 1, N - 1);
            ReverseArray(A, i, j);
        }
        System.out.println(A);

    }
    public static ArrayList<Integer> ReverseArray(ArrayList<Integer> A, int start, int end){
        while(start<end){
            int temp= A.get(start);
            A.set(start, A.get(end));
            A.set(end, temp);
            start++;
            end--;
        }
        return A;
    }
}