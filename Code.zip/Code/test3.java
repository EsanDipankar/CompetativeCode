import java.util.*;
public class test3 {
    public static void main(String args[]){
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter the no of taste Case:- ");
        int a= scn.nextInt();
        int j=0;
        while(j<a){
            int N= scn.nextInt();
            int sum=0;
            for(int i=1;i<N;i++){
                if(N%i==0){
                    sum +=i;
                }
            }
            j++;
            System.out.println(sum);
        }
    }
}
