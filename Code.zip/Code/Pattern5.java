import java.util.Scanner;

public class Pattern5 {
    public static void main(String args[]){
        Scanner scn= new Scanner(System.in);
        int N= scn.nextInt();
        for(int row =0;row<N;row++){
            for(int col=0;col<2*N;col++){
                if(col<=row || col>=2*N-1-row){
                    System.out.print("*");
                }
                else{
                    System.out.print("_");
                }
            }      
            System.out.println();
        }
    }
}
