import java.util.*;

public class Pattern4 {
    public static void main(String args[]){
        Scanner scn= new Scanner(System.in);
        int N=scn.nextInt();
        for(int row=0;row<N;row++){
            for(int col=0; col<2*N;col++){
                if(col<=N-row-1 || col>=N+row){
                    System.out.print("*");
                }
                else{
                    System.out.print("_");
                }

            }
            System.out.println();
        }
    }
}
