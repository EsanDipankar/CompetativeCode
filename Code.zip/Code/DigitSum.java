import java.util.*;
public class DigitSum {
    public static void main(String args[]){
        Scanner scn = new Scanner(System.in);
        int n=scn.nextInt();
        int sum=0;
        while(n>0){
            int rem=0;
            rem=n%10;
            sum+=rem;
            n/=10;
        }
        System.out.print(sum);
    }
}
